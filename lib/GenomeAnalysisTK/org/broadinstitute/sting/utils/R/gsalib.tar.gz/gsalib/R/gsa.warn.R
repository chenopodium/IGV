gsa.warn <- function(message) {
    gsa.message(sprintf("Warning: %s", message));
}
